var config={
location:true,
camera:true,
camsnaps:4,
redirectURL:"https://google.com"
}



module.exports ={config}
